//#include<bits/stdc++.h>
#include<iostream>
#include<cstring>
using namespace std;
int dp[100][100];



int kanpsack(int val[], int wt[], int capacity, int n)
{
    if(capacity<0 or n<0)
        return 0;
    
    //memoziation - if state is already computed return directly dp value. memoziation reduces recursive calls.
    if(dp[n][capacity]!=-1)
        return dp[n][capacity];
    
    if(wt[n]>capacity)      //skip that current item n and check for previous item
    {
        dp[n][capacity]= kanpsack(val,wt,capacity,n-1);
        return dp[n][capacity];
    }
    else
    {
        dp[n][capacity]=max(    kanpsack(val,wt,capacity,n-1), //leave it- so capacity remains same
                                kanpsack(val,wt,capacity-wt[n],n-1)+val[n]); //take it- so, capacity becomes change and reduce, add profit
                            
        return dp[n][capacity]; 
    }
}
int main()
{
    int item_count, capacity;
    cout<<"Enter item_count: ";
    cin>>item_count;
    
    cout<<"\nEnter capacity: ";
    cin>>capacity;
    
    dp[item_count][capacity];
    memset(dp,-1,sizeof(dp));
    
    int val[item_count],weight[item_count];
    cout<<"\nItem Value \t Item Weight\n";
    for(int i=0; i<item_count; i++)
    {
        cin>>val[i];
        cin>>weight[i];
    }
    
    cout<<"\nMaximum  Profit is: "<<kanpsack(val,weight,capacity,item_count-1);
    
    
}


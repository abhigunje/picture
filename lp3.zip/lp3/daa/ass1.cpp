#include <bits/stdc++.h>
#include <iostream>

using namespace std;

int fibonacci_recursive(int n)
{
    if (n <= 1)
        return n;
    return fibonacci_recursive(n - 1) + fibonacci_recursive(n - 2);
}

int fibonacci_iterative(int n)
{
    if (n <= 1)
        return n;

    int prev = 0;
    int current = 1;
    for (int i = 2; i <= n; i++) {
        int next = prev + current;
        prev = current;
        current = next;
    }
    return current;
}

int main()
{
    int n;
    cout << "Enter n : " << endl;
    cin >> n;
    cout << "n'th fibonacci no. with iterative method : " << fibonacci_iterative(n) << endl;
    cout << "n'th fibonacci no. with recursive method : " << fibonacci_recursive(n) << endl;

    return 0;
}

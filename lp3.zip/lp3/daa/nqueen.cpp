#include <iostream>
#include <vector>

using namespace std;  // Add this line to use std:: without a prefix

bool isSafe(const vector<vector<int>>& board, int row, int col, int n) {
    // Check if it's safe to place a queen in this cell
    // Check the row
    for (int i = 0; i < col; i++) {
        if (board[row][i] == 1) {
            return false;
        }
    }

    // Check upper-left diagonal
    for (int i = row, j = col; i >= 0 && j >= 0; i--, j--) {
        if (board[i][j] == 1) {
            return false;
        }
    }

    // Check lower-left diagonal
    for (int i = row, j = col; i < n && j >= 0; i++, j--) {
        if (board[i][j] == 1) {
            return false;
        }
    }

    return true;
}

bool solveNQueens(vector<vector<int>>& board, int col, int n) {
    if (col >= n) {
        return true;  // All queens are placed
    }

    for (int i = 0; i < n; i++) {
        if (isSafe(board, i, col, n)) {
            board[i][col] = 1;  // Place the queen

            if (solveNQueens(board, col + 1, n)) {
                return true;  // Recursively place the remaining queens
            }

            board[i][col] = 0;  // If no solution found, backtrack
        }
    }

    return false;  // No solution found
}

void printBoard(const vector<vector<int>>& board) {
    for (const auto& row : board) {
        for (int cell : row) {
            if (cell == 1) {
                cout << "Q ";
            } else {
                cout << ". ";
            }
        }
        cout << "\n";
    }
}

int main() {
    int n = 8;  // Change 'n' to the desired board size
    int firstQueenRow = 0;  // Change to the row where you want to place the first queen

    if (firstQueenRow < 0 || firstQueenRow >= n) {
        cout << "Invalid position for the first queen." << endl;
        return 1;
    }

    vector<vector<int>> board(n, vector<int>(n, 0));
    board[firstQueenRow][0] = 1;

    if (solveNQueens(board, 1, n)) {
        cout << "N-Queens solution:\n";
        printBoard(board);
    } else {
        cout << "No solution found." << endl;
    }

    return 0;
}


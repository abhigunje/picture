#include <iostream>
#include <queue>
#include <map>
#include <string>

using namespace std;

struct HuffmanNode {
    char data;
    int frequency;
    HuffmanNode* left;
    HuffmanNode* right;

    HuffmanNode(char data, int frequency) : data(data), frequency(frequency), left(nullptr), right(nullptr) {}
};

struct Compare {
    bool operator()(HuffmanNode* a, HuffmanNode* b) {
        return a->frequency > b->frequency;
    }
};

void buildHuffmanTree(map<char, int>& freqMap, HuffmanNode*& root) {
    priority_queue<HuffmanNode*, vector<HuffmanNode*>, Compare> pq;

    for (auto it = freqMap.begin(); it != freqMap.end(); ++it) {
        pq.push(new HuffmanNode(it->first, it->second));
    }

    while (pq.size() > 1) {
        HuffmanNode* left = pq.top();
        pq.pop();
        HuffmanNode* right = pq.top();
        pq.pop();

        HuffmanNode* newNode = new HuffmanNode('\0', left->frequency + right->frequency);
        newNode->left = left;
        newNode->right = right;
        pq.push(newNode);
    }

    root = pq.top();
}

void buildHuffmanCodes(HuffmanNode* root, string code, map<char, string>& huffmanCodes) {
    if (!root)
        return;

    if (root->data != '\0') {
        huffmanCodes[root->data] = code;
    }

    buildHuffmanCodes(root->left, code + "0", huffmanCodes);
    buildHuffmanCodes(root->right, code + "1", huffmanCodes);
}

string huffmanEncoding(string data) {
    map<char, int> freqMap;
    for (char c : data) {
        freqMap[c]++;
    }

    HuffmanNode* root = nullptr;
    buildHuffmanTree(freqMap, root);

    map<char, string> huffmanCodes;
    buildHuffmanCodes(root, "", huffmanCodes);

    string encodedData = "";
    for (char c : data) {
        encodedData += huffmanCodes[c];
    }

    return encodedData;
}

int main() {
    string data = "this is an example for huffman encoding";
    string encodedData = huffmanEncoding(data);

    cout << "Original Data: " << data << endl;
    cout << "Encoded Data: " << encodedData << endl;

    return 0;
}


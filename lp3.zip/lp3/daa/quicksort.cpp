#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>
#include <chrono>
using namespace std;
// Partition function for deterministic Quick Sort
int deterministicPartition(std::vector<int>& arr, int low, int high) {
    int pivot = arr[high];
    int i = (low - 1);

    for (int j = low; j < high; j++) {
        if (arr[j] <= pivot) {
            i++;
            swap(arr[i], arr[j]);
        }
    }

    swap(arr[i + 1], arr[high]);
    return i + 1;
}

// Quick Sort using the deterministic pivot selection
void deterministicQuickSort(std::vector<int>& arr, int low, int high) {
    if (low < high) {
        int pivotIndex = deterministicPartition(arr, low, high);

        deterministicQuickSort(arr, low, pivotIndex - 1);
        deterministicQuickSort(arr, pivotIndex + 1, high);
    }
}

// Randomized partition function for Quick Sort
int randomizedPartition(std::vector<int>& arr, int low, int high) {
    int pivotIndex = low + rand() % (high - low + 1);
    swap(arr[pivotIndex], arr[high]);
    return deterministicPartition(arr, low, high);
}

// Quick Sort using the randomized pivot selection
void randomizedQuickSort(std::vector<int>& arr, int low, int high) {
    if (low < high) {
        int pivotIndex = randomizedPartition(arr, low, high);

        randomizedQuickSort(arr, low, pivotIndex - 1);
        randomizedQuickSort(arr, pivotIndex + 1, high);
    }
}

int main() {
    srand(static_cast<unsigned int>(time(nullptr))); // Seed the random number generator

    int n = 100000; // Change 'n' to the desired array size
    vector<int> arr(n);
    for (int i = 0; i < n; i++) {
        arr[i] = rand(); // Fill the array with random values
    }

    vector<int> arrCopy = arr; // Create a copy for deterministic Quick Sort

    // Measure execution time for deterministic Quick Sort
    auto start = chrono::high_resolution_clock::now();
    deterministicQuickSort(arrCopy, 0, n - 1);
    auto stop = chrono::high_resolution_clock::now();
    auto deterministicDuration = chrono::duration_cast<chrono::milliseconds>(stop - start);

    // Measure execution time for randomized Quick Sort
    start = chrono::high_resolution_clock::now();
    randomizedQuickSort(arr, 0, n - 1);
    stop = chrono::high_resolution_clock::now();
    auto randomizedDuration = chrono::duration_cast<chrono::milliseconds>(stop - start);

    cout << "Deterministic Quick Sort took " << deterministicDuration.count() << " milliseconds." << endl;
    cout << "Randomized Quick Sort took " << randomizedDuration.count() << " milliseconds." << endl;

    return 0;
}

